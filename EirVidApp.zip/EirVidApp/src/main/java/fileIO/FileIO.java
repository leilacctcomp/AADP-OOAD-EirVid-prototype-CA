/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fileIO;

/**
 * @author leila
 */
public class FileIO {

    protected String filename; // The default filename

    public FileIO(String filename) {
        this.filename = filename;
    }
}
