/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fileIO;

import java.util.ArrayList;

/**
 * @author leila
 */
public class CSVReaderDecorator extends FileIO implements CSVReaderChecker{

   private CSVReaderChecker csvReader;

    public CSVReaderDecorator(String filename) {
        super(filename);
        this.csvReader = new CSVReader(filename);
    }

    @Override
    public ArrayList<String> readData() {
        ArrayList<String> data = csvReader.readData();
        if (data.isEmpty()) {
            System.out.println("The file: " + filename + ".csv cannot be located or it is empty.");
        }
        return data;
    }
}
