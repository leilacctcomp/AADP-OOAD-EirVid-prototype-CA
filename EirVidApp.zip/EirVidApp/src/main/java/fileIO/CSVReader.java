/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fileIO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author leila
 */
public class CSVReader extends FileIO implements CSVReaderChecker{

    public CSVReader(String filename) {
        super(filename); // FileIO constructor
    }

    @Override
    public ArrayList<String> readData() {
        ArrayList<String> data = new ArrayList<>();
        String line;

        try (BufferedReader br = new BufferedReader(new FileReader(this.filename))) {
            while ((line = br.readLine()) != null) {
                data.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from CSV file: " + e.getMessage());
        }

        return data;
    }
}
