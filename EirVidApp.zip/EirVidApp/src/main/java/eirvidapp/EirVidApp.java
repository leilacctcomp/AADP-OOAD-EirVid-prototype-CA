/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package eirvidapp;

import fileIO.CSVReaderChecker;
import fileIO.CSVReaderDecorator;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import movie_rental_system.Movie;
import movie_rental_system.MovieManager;
import movie_rental_system.RecommendationEngine;
import movie_rental_system.Rental;
import movie_rental_system.RentalManager;
import user.AccountManager;
import user.User;

public class EirVidApp {

    public static void main(String[] args) {
        String csvFilename = "Movie_Metadata.csv"; // CSV file
        CSVReaderChecker csvReader = new CSVReaderDecorator(csvFilename);

        Scanner scanner = new Scanner(System.in);
        AccountManager accountManager = new AccountManager();
        MovieManager movieManager = new MovieManager();
        RentalManager rentalManager = new RentalManager();
        RecommendationEngine recommendationEngine = new RecommendationEngine(rentalManager);

        // Load movies into movieManager to be listed
        movieManager.loadMovies(csvFilename);

        // User registration and login
        System.out.println("Welcome to ÉirVid! Please register or login.");
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        User user = accountManager.loginUser(email, password);
        if (user == null) {
            accountManager.registerUser(email, password);
            user = accountManager.loginUser(email, password);
            System.out.println("Registration successful. You are now logged in.");
        } else {
            System.out.println("Login successful.");
        }

        // List of available movies
        movieManager.listAllMovies();

        // Ask user to select a movie
        System.out.print("Enter the title of the movie you want to rent: ");
        String movieTitle = scanner.nextLine();
        Movie movie = movieManager.getMovie(movieTitle);
        if (movie != null) {
            Rental rental = rentalManager.recordRental(user, movie);

            //Display due back time
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDateTime = rental.getDueBackTime().format(formatter);
            System.out.println("You have rented '" + movie.getTitle() + "'.");
            System.out.println("It is due back: " + formattedDateTime);
            
        } else {
            System.out.println("Movie not found.");
        }

        // Check for overdue rentals
        List<Rental> overdueRentals = rentalManager.getOverdueRentalsForUser(user);
        if (!overdueRentals.isEmpty()) {
            System.out.println("You have overdue rentals:");
            for (Rental overdueRental : overdueRentals) {
                System.out.println("Movie: " + overdueRental.getMovie().getTitle()
                        + ", Due Back: " + overdueRental.getDueBackTime().toString());
            }
        } else {
            System.out.println("You have no overdue rentals.");
        }

        // Recommend movies
        List<Movie> recommendedMovies = recommendationEngine.recommendMovies();
        System.out.println("Recommended movies for you:");
        for (Movie recommendedMovie : recommendedMovies) {
            System.out.println(recommendedMovie.getTitle() + " - $" + recommendedMovie.getPrice());
        }

        scanner.close();
    }
}
