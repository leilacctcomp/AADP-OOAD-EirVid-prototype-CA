/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movie_rental_system;

import data_reader.TimeManager;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author leila
 */
public class RecommendationEngine {

    private RentalManager rentalManager;

    public RecommendationEngine(RentalManager rentalManager) {
        this.rentalManager = rentalManager;
    }

    public List<Movie> recommendMovies() {
        Map<Movie, Long> movieCount = rentalManager.getRentals().stream()
                // Filter for rentals in the last 5 minutes
                .filter(rental -> TimeManager.isWithinLastMinutes(rental.getRentalStartTime(), 5))
                // Collect movies and count occurrences
                .collect(Collectors.groupingBy(Rental::getMovie, Collectors.counting()));

        // Return the top 5 rented movies
        return movieCount.entrySet().stream()
                .sorted(Map.Entry.<Movie, Long>comparingByValue().reversed())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }
}
