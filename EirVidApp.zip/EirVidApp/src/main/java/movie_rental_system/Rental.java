/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movie_rental_system;

import java.time.LocalDateTime;
import user.User;
import data_reader.TimeManager;

public class Rental {

    private User user;
    private Movie movie;
    private LocalDateTime rentalStartTime;
    private LocalDateTime dueBackTime;

    public Rental(User user, Movie movie) {
        this.user = user;
        this.movie = movie;
        this.rentalStartTime = LocalDateTime.now();
        this.dueBackTime = rentalStartTime.plusMinutes(1); // Rental time is 1 minute per movie
    }

    public boolean isRentalOverdue() {
        return !TimeManager.isWithinLastMinutes(dueBackTime, 1);
    }
    // Getters and setters

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public LocalDateTime getRentalStartTime() {
        return rentalStartTime;
    }

    public void setRentalStartTime(LocalDateTime rentalStartTime) {
        this.rentalStartTime = rentalStartTime;
    }

    public LocalDateTime getDueBackTime() {
        return dueBackTime;
    }

    public void setDueBackTime(LocalDateTime dueBackTime) {
        this.dueBackTime = dueBackTime;
    }

}
