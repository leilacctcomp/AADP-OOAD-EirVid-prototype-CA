/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movie_rental_system;

import java.util.ArrayList;
import java.util.List;
import user.User;

/**
 * @author leila
 */
public class RentalManager {

    private List<Rental> rentals = new ArrayList<>();

    public Rental recordRental(User user, Movie movie) {
        Rental rental = new Rental(user, movie);
        rentals.add(rental);
        // Output customer, movie, and price to the console after a movie is rented
        System.out.println("\nRental Details:");
        System.out.println("Customer Email: " + user.getEmail());
        System.out.println("Movie Title: " + movie.getTitle());
        System.out.println("Rental Price: $" + String.format("%.2f", movie.getPrice()));
        return rental; // Return the rental object
    }

    public List<Rental> getUserRentals(User user) {
        List<Rental> userRentals = new ArrayList<>();
        for (Rental rental : rentals) {
            if (rental.getUser().equals(user)) {
                userRentals.add(rental);
            }
        }
        return userRentals;
    }

    public List<Rental> getRentals() {
        return new ArrayList<>(rentals); // Return a new list to avoid outside modifications
    }

    public List<Rental> getOverdueRentals() {
        List<Rental> overdueRentals = new ArrayList<>();
        for (Rental rental : rentals) {
            if (rental.isRentalOverdue()) {
                overdueRentals.add(rental);
            }
        }
        return overdueRentals;
    }

    public List<Rental> getOverdueRentalsForUser(User user) {
        List<Rental> userOverdueRentals = new ArrayList<>();
        for (Rental rental : rentals) {
            if (rental.getUser().equals(user) && rental.isRentalOverdue()) {
                userOverdueRentals.add(rental);
            }
        }
        return userOverdueRentals;
    }
}
