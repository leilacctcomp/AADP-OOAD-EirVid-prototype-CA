/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movie_rental_system;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 * @author leila
 */
public class MovieManager {

    private Map<String, Movie> movies = new HashMap<>();

    public void loadMovies(String filePath) {
        List<Movie> movieList = parseMovies(filePath);
        for (Movie movie : movieList) {
            movies.put(movie.getTitle(), movie);
        }
    }

    private List<Movie> parseMovies(String filePath) {
        List<Movie> movieList = new ArrayList<>();
        try ( Reader reader = Files.newBufferedReader(Paths.get(filePath));  CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {

            for (CSVRecord csvRecord : csvParser) {
                String title = csvRecord.get("title");
                double price = Double.parseDouble(csvRecord.get("price"));
                movieList.add(new Movie(title, price));
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return movieList;
    }

    public Movie getMovie(String title) {
        return movies.get(title);
    }

    // Method to list all movie titles available to be rented
    public void listAllMovies() {
        System.out.println("Available Movies:");
        for (Movie movie : movies.values()) {
            // To see what's being returned by getTitle()
            //System.out.println("Debug: Movie title from object: " + movie.getTitle());
            System.out.println(movie.getTitle());
        }
    }
}
