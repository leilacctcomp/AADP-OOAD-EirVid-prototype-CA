/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data_reader;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * @author leila
 * TimeManager class is responsible for managing time-related functionalities.
 * This method checks if the given timestamp is within the specified minutes from the current time.
 */
public class TimeManager {

    public static boolean isWithinLastMinutes(LocalDateTime timestamp, int minutes) {
        return timestamp.isAfter(LocalDateTime.now().minusMinutes(minutes));
    }
}
